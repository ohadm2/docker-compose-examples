#!/usr/bin/env bash
set -e

CONFIG_FILE="/etc/gitlab-runner/config.toml"
CI_SERVER_URL="http://gitlab"

# Wait until GitLab is ready
echo "⏳ Waiting for GitLab to be ready..."
until curl -s "$CI_SERVER_URL/users/sign_in" >/dev/null; do
  sleep 5
done
echo "✅ GitLab is ready!"

# Extract the registration token from GitLab API
if [ ! -f "$CONFIG_FILE" ]; then
    echo "➡ Fetching registration token..."
    TOKEN=$(docker exec gitlab grep 'Registration token:' /var/opt/gitlab/gitlab-rails/etc/gitlab.rb || true)

    # If not found in file, fallback: create a temporary root API token
    if [ -z "$TOKEN" ]; then
        echo "Creating temporary root token..."
        ROOT_PASSWORD=$(docker exec gitlab grep 'Password:' /etc/gitlab/initial_root_password | awk '{print $2}')
        LOGIN_JSON=$(curl -s -X POST -d "login=root&password=$ROOT_PASSWORD" "$CI_SERVER_URL/users/sign_in")
        # This is a simple placeholder. For full automation, the GitLab API can generate a token
        TOKEN=$(docker exec gitlab grep 'Registration token:' /var/opt/gitlab/gitlab-rails/etc/gitlab.rb | awk '{print $3}')
    fi

    echo "➡ Registering runner..."
    gitlab-runner register \
      --non-interactive \
      --url "$CI_SERVER_URL" \
      --registration-token "$TOKEN" \
      --executor docker \
      --docker-image docker:latest \
      --description "auto-runner" \
      --tag-list "docker" \
      --run-untagged=true \
      --locked=false
fi

echo "➡ Starting runner..."
gitlab-runner run --user=gitlab-runner --working-directory=/home/gitlab-runner

