# Use Alpine Linux as the base image
FROM alpine:latest

USER root
# Install rsyslog
RUN apk add --no-cache rsyslog

# Configure rsyslog
# Add your rsyslog configuration files if needed

# Expose the rsyslog port
EXPOSE 5514

# Start rsyslog as the entrypoint
ENTRYPOINT ["rsyslogd", "-n"]

