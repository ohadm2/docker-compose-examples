ARG php_tag
FROM wodby/drupal-php:$php_tag
USER root
# Install some apps
RUN apk update && \
    apk add vim && \
    apk add git-bash-completion
# Add sudo privileges
RUN echo "%wheel ALL=(ALL) NOPASSWD: ALL" >> /etc/sudoers
RUN apk add sudo && \
    addgroup wodby wheel && \
    rm -rf /var/cache/apk/*
# Install compass (also possible from: elnebuloso/compass)
RUN apk add linux-headers && \
    apk add build-base && \
    apk add ruby-dev && \
    gem install compass
# Install nodejs, npm, angular-cli
ARG nodejs_tag
ARG npm_tag
ARG angular_tag
RUN echo 'https://dl-cdn.alpinelinux.org/alpine/v3.14/main' >> /etc/apk/repositories
RUN curl -LO https://dl-cdn.alpinelinux.org/alpine/v3.14/main/x86_64/nodejs-${nodejs_tag}-r0.apk && \
    curl -LO https://dl-cdn.alpinelinux.org/alpine/v3.14/main/x86_64/npm-${npm_tag}-r0.apk && \
    apk add ./nodejs-${nodejs_tag}-r0.apk ./npm-${npm_tag}-r0.apk && \
    npm i -g @angular/cli@${angular_tag} \
    npm install -g sass

# Install and add settings to rsyslog
#RUN apk add rsyslog
#RUN echo "local0.* /var/log/rsyslog-my-log.log" >> /etc/rsyslog.conf

USER wodby

# Install php codesniffer
RUN composer global require "squizlabs/php_codesniffer=*"; \
    composer global config --no-plugins allow-plugins.dealerdirect/phpcodesniffer-composer-installer true; \
    composer global require drupal/coder;

#CMD sudo /usr/sbin/rsyslogd && php-fpm
