from flask import Flask, request, jsonify, render_template_string
from ldap3 import Server, Connection, ALL

app = Flask(__name__)

LDAP_SERVER = "ldap://openldap:389"
BASE_DN = "ou=users,dc=example,dc=com"

# HTML Login Form
LOGIN_PAGE = """
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>LDAP Login</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background: #f0f2f5;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
        }
        form {
            background: white;
            padding: 2em;
            border-radius: 10px;
            box-shadow: 0 0 10px rgba(0,0,0,0.1);
        }
        h2 {
            margin-top: 0;
            text-align: center;
        }
        input[type="text"], input[type="password"] {
            width: 100%;
            padding: 10px;
            margin: 8px 0;
            border: 1px solid #ccc;
            border-radius: 5px;
        }
        button {
            width: 100%;
            padding: 10px;
            background: #007BFF;
            color: white;
            border: none;
            border-radius: 5px;
            cursor: pointer;
        }
        button:hover {
            background: #0056b3;
        }
        .msg {
            margin-top: 10px;
            text-align: center;
            color: red;
        }
        .success {
            color: green;
        }
    </style>
</head>
<body>
    <form method="POST" action="/login">
        <h2>LDAP Login</h2>
        <input type="text" name="username" placeholder="Username" required>
        <input type="password" name="password" placeholder="Password" required>
        <button type="submit">Login</button>
        {% if message %}
            <div class="msg {{ 'success' if success else '' }}">{{ message }}</div>
        {% endif %}
    </form>
</body>
</html>
"""

def authenticate(username, password):
    """Authenticate a user against the LDAP server."""
    user_dn = f"uid={username},{BASE_DN}"
    server = Server(LDAP_SERVER, get_info=ALL)
    try:
        conn = Connection(server, user=user_dn, password=password, auto_bind=True)
        conn.unbind()
        return True
    except Exception as e:
        print(f"[LDAP ERROR] Authentication failed for user '{username}': {e}")
        return False


@app.route("/login", methods=["GET", "POST"])
def login():
    # --- GET: render the login UI ---
    if request.method == "GET":
        return render_template_string(LOGIN_PAGE)

    # --- POST: handle form or JSON login ---
    username = None
    password = None

    if request.content_type == "application/json":
        data = request.get_json(silent=True) or {}
        username = data.get("username")
        password = data.get("password")
    else:
        username = request.form.get("username")
        password = request.form.get("password")

    if not username or not password:
        return render_template_string(LOGIN_PAGE, message="Username and password are required", success=False)

    # ✅ Explicitly call authenticate()
    if authenticate(username, password):
        # Return success differently depending on request type
        if request.content_type == "application/json":
            return jsonify({"status": "success", "user": username})
        return render_template_string(LOGIN_PAGE, message=f"✅ Welcome, {username}!", success=True)
    else:
        if request.content_type == "application/json":
            return jsonify({"status": "failure"}), 401
        return render_template_string(LOGIN_PAGE, message="❌ Invalid credentials", success=False), 401


if __name__ == "__main__":
    app.run(host="0.0.0.0", port=5000)

